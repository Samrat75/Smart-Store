package com.mvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Strore1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
